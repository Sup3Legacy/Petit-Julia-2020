
struct s a::Int64; b::Array end

function s(a::Float64, b::Int64) a+b end

println(s(float(3),3))
