
let div = ref false
let char = ref false
let int = ref false
let float = ref false

let input_int = ref false

let ge = ref false
let g = ref false
let le = ref false
let l = ref false

let add = ref false
let mul = ref false
let sub = ref false
