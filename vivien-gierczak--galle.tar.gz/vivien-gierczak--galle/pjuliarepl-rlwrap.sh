rlwrap -f pjulia-words -c -pCyan ./pjuliarepl
